<div class="jumbotron" style="background-color:#F0FFFF; border-radius:10px;">

<br>
<h3>Bem vindo(a) ao People Manager</h3>
<hr>
<p>	O People Manager � um sistema para cadastro, consulta, edi��o e dele��o de pessoas. Utilize
os bot�es do menu para acessar as op��es. Para editar ou apagar uma pessoa, fa�a primeiro uma pesquisa
ou acesse a listagem.	</p>
	
</div>
